import { FC } from 'react';
import Home from './components/pages/Home';

const App: FC = () => {
  return (
    <Home />
  );
};

export default App;
